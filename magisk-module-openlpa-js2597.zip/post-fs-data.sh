#!/system/bin/sh
resetprop -nv ro.debuggable 1
resetprop persist.service.seek "fullaccess"
